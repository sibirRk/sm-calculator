import './index.scss';
import './js/script';
import './js/calc';