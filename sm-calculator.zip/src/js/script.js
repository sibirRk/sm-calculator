// import noUiSlider from 'nouislider';
//
// let priceInput = document.querySelector('.sm-calculator__input_price');
//
// noUiSlider.create(priceInput, {
//   start: [20, 80],
//   connect: true,
//   range: {
//     'min': 0,
//     'max': 100
//   }
// });
